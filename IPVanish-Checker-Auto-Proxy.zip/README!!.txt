Hola gracias por usar mis programas

Te explico algo rápido
Para que el checker vaya rapido necesitas de proxys de paga
Pero si no tienes normal puedes usar proxyscrape, Las proxys
que sean tipo Socks4.
Recuerda que si usas proxys públicas va a correr a una velocidad
no lenta sino media.

Los hits se van a guardar en tu escritorio con un block de notas.
USA UN VPN PARA PODER INGRESAR

#Gracias #Suerte con tus Hits ;)

Atentamente: @AlexanderPoint
Buscame en Telegram

ENGLISH

Hello thanks for using my programs

I explain something quick
For the checker to go fast you need payment proxies
But if you don't have normal you can use proxyscrape, The proxies
that are type Socks4.
Remember that if you use public proxies it will run at a speed
not slow but medium.

The hits will be saved on your desktop with a notepad.
USE A VPN TO BE ABLE TO ENTER

#Thank you #Luck with your Hits;)

Sincerely: @AlexanderPoint
Find me on Telegram